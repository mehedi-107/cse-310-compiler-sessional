.MODEL SMALL
.STACK 1000H
.DATA
	number DB "00000$"
.CODE
main PROC
	MOV AX, @DATA
	MOV DS, AX
	PUSH BP
	MOV BP, SP
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
L2:
	MOV AX, 0		; line 5
	PUSH AX
	POP AX
	MOV [BP-2], AX
L3:
L4:
	MOV AX, 6		; line 5
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 5
	CMP AX, DX
	JL L5		; line 5
	JMP L6		; line 5
L5:
	MOV AX, 1		; line 5
	JMP L7		; line 5
L6:
	MOV AX, 0		; line 5
L7:
	PUSH AX		; line 5
	POP AX		; line 5
	CMP AX, 0		; line 5
	JE L8		; line 5
	JMP L9		; line 5
L10:
	MOV AX, [BP-2]		; line 5
	PUSH AX		; line 5
	INC AX		; line 5
	MOV [BP-2], AX		; line 5
	JMP L3		; line 5
L9:
L11:
	MOV AX, [BP-2]		; line 6
	CALL print_output
	CALL new_line
L12:
	JMP L10		; line 7
L8:
L13:
	MOV AX, 4		; line 9
	PUSH AX
	POP AX
	MOV [BP-6], AX
L14:
	MOV AX, 6		; line 10
	PUSH AX
	POP AX
	MOV [BP-8], AX
L15:
L16:
	MOV AX, 0		; line 11
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-6]		; line 11
	CMP AX, DX
	JG L17		; line 11
	JMP L18		; line 11
L17:
	MOV AX, 1		; line 11
	JMP L19		; line 11
L18:
	MOV AX, 0		; line 11
L19:
	PUSH AX		; line 11
	POP AX
	CMP AX, 0
	JE L20
L21:
L22:
	MOV AX, 3		; line 12
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-8]		; line 12
	ADD AX, DX
	PUSH AX		; line 12
	POP AX
	MOV [BP-8], AX
L23:
	MOV AX, [BP-6]		; line 13
	PUSH AX		; line 13
	DEC AX		; line 13
	MOV [BP-6], AX		; line 13
	JMP L15		; line 14
L20:
L24:
	MOV AX, [BP-8]		; line 16
	CALL print_output
	CALL new_line
L25:
	MOV AX, [BP-6]		; line 17
	CALL print_output
	CALL new_line
L26:
	MOV AX, 4		; line 19
	PUSH AX
	POP AX
	MOV [BP-6], AX
L27:
	MOV AX, 6		; line 20
	PUSH AX
	POP AX
	MOV [BP-8], AX
L28:
L29:
	MOV AX, [BP-6]		; line 22
	PUSH AX		; line 22
	DEC AX		; line 22
	MOV [BP-6], AX		; line 22
	POP AX
	CMP AX, 0
	JE L30
L31:
L32:
	MOV AX, 3		; line 23
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-8]		; line 23
	ADD AX, DX
	PUSH AX		; line 23
	POP AX
	MOV [BP-8], AX
	JMP L28		; line 24
L30:
L33:
	MOV AX, [BP-8]		; line 26
	CALL print_output
	CALL new_line
L34:
	MOV AX, [BP-6]		; line 27
	CALL print_output
	CALL new_line
L35:
	MOV AX, 0		; line 30
	PUSH AX
	POP AX		; line 30
	JMP L1		; line 30
L1:
	MOV SP, BP
	POP BP
	MOV AX, 4CH
	INT 21H
main ENDP
new_line proc
	push ax
	push dx
	mov ah,2
	mov dl,0Dh
	int 21h
	mov ah,2
	mov dl,0Ah
	int 21h
	pop dx
	pop ax
	ret
new_line endp
print_output proc  ;print what is in ax
	push ax
	push bx
	push cx
	push dx
	push si
	lea si,number
	mov bx,10
	add si,4
	cmp ax,0
	jnge negate
print:
	xor dx,dx
	div bx
	mov [si],dl
	add [si],'0'
	dec si
	cmp ax,0
	jne print
	inc si
	lea dx,si
	mov ah,9
	int 21h
	pop si
	pop dx
	pop cx
	pop bx
	pop ax
	ret
negate:
	push ax
	mov ah,2
	mov dl,'-'
	int 21h
	pop ax
	neg ax
	jmp print
print_output endp
END main
