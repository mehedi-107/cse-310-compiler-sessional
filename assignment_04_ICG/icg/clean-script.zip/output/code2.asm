.MODEL SMALL
.STACK 1000H
.DATA
	number DB "00000$"
.CODE
main PROC
	MOV AX, @DATA
	MOV DS, AX
	PUSH BP
	MOV BP, SP
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
L2:
	MOV AX, 3		; line 5
	PUSH AX
	POP AX
	MOV [BP-2], AX
L3:
	MOV AX, 8		; line 6
	PUSH AX
	POP AX
	MOV [BP-4], AX
L4:
	MOV AX, 6		; line 7
	PUSH AX
	POP AX
	MOV [BP-6], AX
L5:
L6:
	MOV AX, 3		; line 10
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 10
	CMP AX, DX
	JE L7		; line 10
	JMP L8		; line 10
L7:
	MOV AX, 1		; line 10
	JMP L9		; line 10
L8:
	MOV AX, 0		; line 10
L9:
	PUSH AX		; line 10
	POP AX		; line 
	CMP AX, 0		; line 
	JE L10
L11:
	MOV AX, [BP-4]		; line 11
	CALL print_output
	CALL new_line
L10:
L12:
L13:
	MOV AX, 8		; line 14
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-4]		; line 14
	CMP AX, DX
	JL L14		; line 14
	JMP L15		; line 14
L14:
	MOV AX, 1		; line 14
	JMP L16		; line 14
L15:
	MOV AX, 0		; line 14
L16:
	PUSH AX		; line 14
	POP AX		; line 14
	CMP AX, 0		; line 14
	JE L17		; line 14
L18:
	MOV AX, [BP-2]		; line 15
	CALL print_output
	CALL new_line
	JMP L19		; line 16
L17:
L20:
	MOV AX, [BP-6]		; line 18
	CALL print_output
	CALL new_line
L19:
L21:
L22:
	MOV AX, 6		; line 21
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-6]		; line 21
	CMP AX, DX
	JNE L23		; line 21
	JMP L24		; line 21
L23:
	MOV AX, 1		; line 21
	JMP L25		; line 21
L24:
	MOV AX, 0		; line 21
L25:
	PUSH AX		; line 21
	POP AX		; line 21
	CMP AX, 0		; line 21
	JE L26		; line 21
L27:
	MOV AX, [BP-6]		; line 22
	CALL print_output
	CALL new_line
	JMP L28		; line 23
L26:
L29:
L30:
	MOV AX, 8		; line 24
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-4]		; line 24
	CMP AX, DX
	JG L31		; line 24
	JMP L32		; line 24
L31:
	MOV AX, 1		; line 24
	JMP L33		; line 24
L32:
	MOV AX, 0		; line 24
L33:
	PUSH AX		; line 24
	POP AX		; line 24
	CMP AX, 0		; line 24
	JE L34		; line 24
L35:
	MOV AX, [BP-4]		; line 25
	CALL print_output
	CALL new_line
	JMP L36		; line 26
L34:
L37:
L38:
	MOV AX, 5		; line 27
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 27
	CMP AX, DX
	JL L39		; line 27
	JMP L40		; line 27
L39:
	MOV AX, 1		; line 27
	JMP L41		; line 27
L40:
	MOV AX, 0		; line 27
L41:
	PUSH AX		; line 27
	POP AX		; line 27
	CMP AX, 0		; line 27
	JE L42		; line 27
L43:
	MOV AX, [BP-2]		; line 28
	CALL print_output
	CALL new_line
	JMP L44		; line 29
L42:
L45:
	MOV AX, 0		; line 31
	PUSH AX
	POP AX
	MOV [BP-6], AX
L46:
	MOV AX, [BP-6]		; line 32
	CALL print_output
	CALL new_line
L44:
L36:
L28:
L47:
	MOV AX, 0		; line 36
	PUSH AX
	POP AX		; line 36
	JMP L1		; line 36
L1:
	MOV SP, BP
	POP BP
	MOV AX, 4CH
	INT 21H
main ENDP
new_line proc
	push ax
	push dx
	mov ah,2
	mov dl,0Dh
	int 21h
	mov ah,2
	mov dl,0Ah
	int 21h
	pop dx
	pop ax
	ret
new_line endp
print_output proc  ;print what is in ax
	push ax
	push bx
	push cx
	push dx
	push si
	lea si,number
	mov bx,10
	add si,4
	cmp ax,0
	jnge negate
print:
	xor dx,dx
	div bx
	mov [si],dl
	add [si],'0'
	dec si
	cmp ax,0
	jne print
	inc si
	lea dx,si
	mov ah,9
	int 21h
	pop si
	pop dx
	pop cx
	pop bx
	pop ax
	ret
negate:
	push ax
	mov ah,2
	mov dl,'-'
	int 21h
	pop ax
	neg ax
	jmp print
print_output endp
END main
