.MODEL SMALL
.STACK 1000H
.DATA
	number DB "00000$"
	w DW 10 DUP (0000H)
.CODE
main PROC
	MOV AX, @DATA
	MOV DS, AX
	PUSH BP
	MOV BP, SP
	SUB SP, 2
	SUB SP, 20
L2:
	MOV AX, 0		; line 6
	PUSH AX
	MOV AX, 2		; line 6
	PUSH AX
	POP AX
	NEG AX		; line 6
	PUSH AX		; line 6
	POP AX
	POP BX
	PUSH AX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	POP AX
	MOV w[BX], AX
L3:
	MOV AX, 0		; line 7
	PUSH AX
	MOV AX, 0		; line 7
	PUSH AX
L4:
	POP BX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, w[BX]
	PUSH AX
	POP AX
	POP BX
	PUSH AX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, 22
	SUB AX, BX
	MOV BX, AX
	POP AX
	MOV SI, BX
	NEG SI
	MOV [BP + SI], AX
L5:
	MOV AX, 0		; line 8
	PUSH AX
L6:
	POP BX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, 22
	SUB AX, BX
	MOV BX, AX
	MOV SI, BX
	NEG SI
	MOV AX, [BP + SI]
	PUSH AX
	POP AX
	MOV [BP-2], AX
L7:
	MOV AX, [BP-2]		; line 9
	CALL print_output
	CALL new_line
L8:
	MOV AX, 1		; line 10
	PUSH AX
	MOV AX, 0		; line 10
	PUSH AX
L9:
	POP BX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, w[BX]
	PUSH AX
	INC AX
	MOV w[BX], AX
	POP AX
	POP BX
	PUSH AX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, 22
	SUB AX, BX
	MOV BX, AX
	POP AX
	MOV SI, BX
	NEG SI
	MOV [BP + SI], AX
L10:
	MOV AX, 1		; line 11
	PUSH AX
L11:
	POP BX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, 22
	SUB AX, BX
	MOV BX, AX
	MOV SI, BX
	NEG SI
	MOV AX, [BP + SI]
	PUSH AX
	POP AX
	MOV [BP-2], AX
L12:
	MOV AX, [BP-2]		; line 12
	CALL print_output
	CALL new_line
L13:
	MOV AX, 0		; line 13
	PUSH AX
L14:
	POP BX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, w[BX]
	PUSH AX
	POP AX
	MOV [BP-2], AX
L15:
	MOV AX, [BP-2]		; line 14
	CALL print_output
	CALL new_line
L16:
L17:
	MOV AX, 0		; line 16
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 16
	ADD AX, DX
	PUSH AX		; line 16
	POP AX
	MOV [BP-2], AX
L18:
L19:
	MOV AX, 0		; line 17
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 17
	SUB AX, DX
	PUSH AX		; line 17
	POP AX
	MOV [BP-2], AX
L20:
L21:
	MOV AX, 1		; line 18
	PUSH AX
	POP AX
	MOV CX, AX
	MOV AX, [BP-2]		; line 18
	CWD
	MUL CX
	PUSH AX		; line 18
	POP AX
	MOV [BP-2], AX
L22:
	MOV AX, [BP-2]		; line 19
	CALL print_output
	CALL new_line
L23:
L24:
	MOV AX, 0		; line 21
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 21
	CMP AX, DX
	JG L25		; line 21
	JMP L26		; line 21
L25:
	MOV AX, 1		; line 21
	JMP L27		; line 21
L26:
	MOV AX, 0		; line 21
L27:
	PUSH AX		; line 21
L28:
	POP AX		; line 21
	CMP AX, 0
	JE L29		; line 21
L30:
	MOV AX, 10		; line 21
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 21
	CMP AX, DX
	JL L31		; line 21
	JMP L32		; line 21
L31:
	MOV AX, 1		; line 21
	JMP L33		; line 21
L32:
	MOV AX, 0		; line 21
L33:
	PUSH AX		; line 21
	POP AX
	CMP AX, 0
	JE L29		; line 21
L34:
	MOV AX, 1
	JMP L35		; line 21
L29:
	MOV AX, 0		; line 21
L35:
	PUSH AX		; line 21
L36:
	POP AX		; line 21
	CMP AX, 0
	JNE L37		; line 21
L38:
	MOV AX, 0		; line 21
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 21
	CMP AX, DX
	JL L39		; line 21
	JMP L40		; line 21
L39:
	MOV AX, 1		; line 21
	JMP L41		; line 21
L40:
	MOV AX, 0		; line 21
L41:
	PUSH AX		; line 21
L42:
	POP AX		; line 21
	CMP AX, 0
	JE L43		; line 21
L44:
	MOV AX, 10		; line 21
	PUSH AX
	POP AX
	NEG AX		; line 21
	PUSH AX		; line 21
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 21
	CMP AX, DX
	JG L45		; line 21
	JMP L46		; line 21
L45:
	MOV AX, 1		; line 21
	JMP L47		; line 21
L46:
	MOV AX, 0		; line 21
L47:
	PUSH AX		; line 21
	POP AX
	CMP AX, 0
	JE L43		; line 21
L48:
	MOV AX, 1
	JMP L49		; line 21
L43:
	MOV AX, 0		; line 21
L49:
	PUSH AX		; line 21
	POP AX
	CMP AX, 0
	JE L50		; line 21
L37:
	MOV AX, 1
	JMP L51		; line 21
L50:
	MOV AX, 0		; line 21
L51:
	PUSH AX		; line 21
	POP AX		; line 21
	CMP AX, 0		; line 21
	JE L52		; line 21
L53:
	MOV AX, 100		; line 22
	PUSH AX
	POP AX
	MOV [BP-2], AX
	JMP L54		; line 22
L52:
L55:
	MOV AX, 200		; line 24
	PUSH AX
	POP AX
	MOV [BP-2], AX
L54:
L56:
	MOV AX, [BP-2]		; line 25
	CALL print_output
	CALL new_line
L57:
	MOV AX, 0		; line 27
	PUSH AX
	POP AX		; line 27
	JMP L1		; line 27
L1:
	MOV SP, BP
	POP BP
	MOV AX, 4CH
	INT 21H
main ENDP
new_line proc
	push ax
	push dx
	mov ah,2
	mov dl,0Dh
	int 21h
	mov ah,2
	mov dl,0Ah
	int 21h
	pop dx
	pop ax
	ret
new_line endp
print_output proc  ;print what is in ax
	push ax
	push bx
	push cx
	push dx
	push si
	lea si,number
	mov bx,10
	add si,4
	cmp ax,0
	jnge negate
print:
	xor dx,dx
	div bx
	mov [si],dl
	add [si],'0'
	dec si
	cmp ax,0
	jne print
	inc si
	lea dx,si
	mov ah,9
	int 21h
	pop si
	pop dx
	pop cx
	pop bx
	pop ax
	ret
negate:
	push ax
	mov ah,2
	mov dl,'-'
	int 21h
	pop ax
	neg ax
	jmp print
print_output endp
END main
