.MODEL SMALL
.STACK 1000H
.DATA
	number DB "00000$"
	i DW 1 DUP (0000H)
	j DW 1 DUP (0000H)
.CODE
main PROC
	MOV AX, @DATA
	MOV DS, AX
	PUSH BP
	MOV BP, SP
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
L2:
	MOV AX, 1		; line 6
	PUSH AX
	POP AX
	MOV i, AX
L3:
	MOV AX, i		; line7
	CALL print_output
	CALL new_line
L4:
	MOV AX, 5		; line 9
	PUSH AX
	MOV AX, 8		; line 9
	PUSH AX
	POP AX
	MOV DX, AX
	POP AX
	ADD AX, DX
	PUSH AX		; line 9
	POP AX
	MOV j, AX
L5:
	MOV AX, j		; line10
	CALL print_output
	CALL new_line
L6:
L7:
	MOV AX, 2		; line 12
	PUSH AX
L8:
	MOV AX, j		; line 12
	MOV CX, AX
	POP AX
	CWD
	MUL CX
	PUSH AX		; line 12
	POP AX
	MOV DX, AX
	MOV AX, i		; line 12
	ADD AX, DX
	PUSH AX		; line 12
	POP AX
	MOV [BP-2], AX
L9:
	MOV AX, [BP-2]		; line 13
	CALL print_output
	CALL new_line
L10:
L11:
	MOV AX, 9		; line 15
	PUSH AX
	POP AX
	MOV CX, AX
	MOV AX, [BP-2]		; line 15
	CWD
	DIV CX
	PUSH DX		; line 15
	POP AX
	MOV [BP-6], AX
L12:
	MOV AX, [BP-6]		; line 16
	CALL print_output
	CALL new_line
L13:
L14:
L15:
	MOV AX, [BP-4]		; line 18
	MOV DX, AX
	MOV AX, [BP-6]		; line 18
	CMP AX, DX
	JLE L16		; line 18
	JMP L17		; line 18
L16:
	MOV AX, 1		; line 18
	JMP L18		; line 18
L17:
	MOV AX, 0		; line 18
L18:
	PUSH AX		; line 18
	POP AX
	MOV [BP-8], AX
L19:
	MOV AX, [BP-8]		; line 19
	CALL print_output
	CALL new_line
L20:
L21:
L22:
	MOV AX, j		; line 21
	MOV DX, AX
	MOV AX, i		; line 21
	CMP AX, DX
	JNE L23		; line 21
	JMP L24		; line 21
L23:
	MOV AX, 1		; line 21
	JMP L25		; line 21
L24:
	MOV AX, 0		; line 21
L25:
	PUSH AX		; line 21
	POP AX
	MOV [BP-10], AX
L26:
	MOV AX, [BP-10]		; line 22
	CALL print_output
	CALL new_line
L27:
L28:
	MOV AX, [BP-8]
	CMP AX, 0
	JNE L29		; line 24
L30:
	MOV AX, [BP-10]
	CMP AX, 0
	JE L32		; line 24
L29:
	MOV AX, 1
	JMP L32		; line 24
L31:
	MOV AX, 0		; line 24
L32:
	PUSH AX		; line 24
	POP AX
	MOV [BP-12], AX
L33:
	MOV AX, [BP-12]		; line 25
	CALL print_output
	CALL new_line
L34:
L35:
	MOV AX, [BP-8]
	CMP AX, 0
	JE L36		; line 27
L37:
	MOV AX, [BP-10]
	CMP AX, 0
	JE L39		; line 27
L38:
	MOV AX, 1
	JMP L40		; line 27
L36:
	MOV AX, 0		; line 27
L39:
	PUSH AX		; line 27
	POP AX
	MOV [BP-12], AX
L40:
	MOV AX, [BP-12]		; line 28
	CALL print_output
	CALL new_line
L41:
	MOV AX, [BP-12]		; line 30
	PUSH AX		; line 30
	INC AX		; line 30
	MOV [BP-12], AX		; line 30
L42:
	MOV AX, [BP-12]		; line 31
	CALL print_output
	CALL new_line
L43:
L44:
	MOV AX, [BP-12]		; line 33
	NEG AX		; line 33
	PUSH AX		; line 33
	POP AX
	MOV [BP-2], AX
L45:
	MOV AX, [BP-2]		; line 34
	CALL print_output
	CALL new_line
L46:
	MOV AX, 0		; line 36
	PUSH AX
	POP AX		; line 36
	JMP L1		; line 36
L1:
	MOV SP, BP
	POP BP
	MOV AX, 4CH
	INT 21H
main ENDP
new_line proc
	push ax
	push dx
	mov ah,2
	mov dl,0Dh
	int 21h
	mov ah,2
	mov dl,0Ah
	int 21h
	pop dx
	pop ax
	ret
new_line endp
print_output proc  ;print what is in ax
	push ax
	push bx
	push cx
	push dx
	push si
	lea si,number
	mov bx,10
	add si,4
	cmp ax,0
	jnge negate
print:
	xor dx,dx
	div bx
	mov [si],dl
	add [si],'0'
	dec si
	cmp ax,0
	jne print
	inc si
	lea dx,si
	mov ah,9
	int 21h
	pop si
	pop dx
	pop cx
	pop bx
	pop ax
	ret
negate:
	push ax
	mov ah,2
	mov dl,'-'
	int 21h
	pop ax
	neg ax
	jmp print
print_output endp
END main
