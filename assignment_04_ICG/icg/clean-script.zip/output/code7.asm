.MODEL SMALL
.STACK 1000H
.DATA
	number DB "00000$"
.CODE
main PROC
	MOV AX, @DATA
	MOV DS, AX
	PUSH BP
	MOV BP, SP
	SUB SP, 2
L2:
L3:
	MOV AX, 0		; line 3
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 3
	CMP AX, DX
	JG L4		; line 3
	JMP L5		; line 3
L4:
	MOV AX, 1		; line 3
	JMP L6		; line 3
L5:
	MOV AX, 0		; line 3
L6:
	PUSH AX		; line 3
L7:
	POP AX		; line 3
	CMP AX, 0
	JNE L8		; line 3
L9:
	MOV AX, 10		; line 3
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 3
	CMP AX, DX
	JL L10		; line 3
	JMP L11		; line 3
L10:
	MOV AX, 1		; line 3
	JMP L12		; line 3
L11:
	MOV AX, 0		; line 3
L12:
	PUSH AX		; line 3
	POP AX
	CMP AX, 0
	JE L14		; line 3
L8:
	MOV AX, 1
	JMP L14		; line 3
L13:
	MOV AX, 0		; line 3
L14:
	PUSH AX		; line 3
	POP AX		; line 3
	CMP AX, 0		; line 3
	JE L15		; line 3
L16:
	MOV AX, 100		; line 4
	PUSH AX
	POP AX
	MOV [BP-2], AX
	JMP L17		; line 4
L15:
L18:
	MOV AX, 200		; line 6
	PUSH AX
	POP AX
	MOV [BP-2], AX
L17:
L19:
L20:
	MOV AX, 20		; line 8
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 8
	CMP AX, DX
	JG L21		; line 8
	JMP L22		; line 8
L21:
	MOV AX, 1		; line 8
	JMP L23		; line 8
L22:
	MOV AX, 0		; line 8
L23:
	PUSH AX		; line 8
L24:
	POP AX		; line 8
	CMP AX, 0
	JE L25		; line 8
L26:
	MOV AX, 30		; line 8
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 8
	CMP AX, DX
	JL L27		; line 8
	JMP L28		; line 8
L27:
	MOV AX, 1		; line 8
	JMP L29		; line 8
L28:
	MOV AX, 0		; line 8
L29:
	PUSH AX		; line 8
	POP AX
	CMP AX, 0
	JE L31		; line 8
L30:
	MOV AX, 1
	JMP L32		; line 8
L25:
	MOV AX, 0		; line 8
L31:
	PUSH AX		; line 8
	POP AX		; line 8
	CMP AX, 0		; line 8
	JE L32		; line 8
L33:
	MOV AX, 300		; line 9
	PUSH AX
	POP AX
	MOV [BP-2], AX
	JMP L34		; line 9
L32:
L35:
	MOV AX, 400		; line 11
	PUSH AX
	POP AX
	MOV [BP-2], AX
L34:
L36:
L37:
	MOV AX, 40		; line 13
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 13
	CMP AX, DX
	JG L38		; line 13
	JMP L39		; line 13
L38:
	MOV AX, 1		; line 13
	JMP L40		; line 13
L39:
	MOV AX, 0		; line 13
L40:
	PUSH AX		; line 13
L41:
	POP AX		; line 13
	CMP AX, 0
	JE L42		; line 13
L43:
	MOV AX, 50		; line 13
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 13
	CMP AX, DX
	JL L44		; line 13
	JMP L45		; line 13
L44:
	MOV AX, 1		; line 13
	JMP L46		; line 13
L45:
	MOV AX, 0		; line 13
L46:
	PUSH AX		; line 13
	POP AX
	CMP AX, 0
	JE L48		; line 13
L47:
	MOV AX, 1
	JMP L49		; line 13
L42:
	MOV AX, 0		; line 13
L48:
	PUSH AX		; line 13
L49:
	POP AX		; line 13
	CMP AX, 0
	JNE L50		; line 13
L51:
	MOV AX, 60		; line 13
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 13
	CMP AX, DX
	JL L52		; line 13
	JMP L53		; line 13
L52:
	MOV AX, 1		; line 13
	JMP L54		; line 13
L53:
	MOV AX, 0		; line 13
L54:
	PUSH AX		; line 13
L55:
	POP AX		; line 13
	CMP AX, 0
	JE L56		; line 13
L57:
	MOV AX, 70		; line 13
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 13
	CMP AX, DX
	JG L58		; line 13
	JMP L59		; line 13
L58:
	MOV AX, 1		; line 13
	JMP L60		; line 13
L59:
	MOV AX, 0		; line 13
L60:
	PUSH AX		; line 13
	POP AX
	CMP AX, 0
	JE L62		; line 13
L61:
	MOV AX, 1
	JMP L63		; line 13
L56:
	MOV AX, 0		; line 13
L62:
	PUSH AX		; line 13
	POP AX
	CMP AX, 0
	JE L64		; line 13
L50:
	MOV AX, 1
	JMP L64		; line 13
L63:
	MOV AX, 0		; line 13
L64:
	PUSH AX		; line 13
	POP AX		; line 13
	CMP AX, 0		; line 13
	JE L65		; line 13
L66:
	MOV AX, 500		; line 14
	PUSH AX
	POP AX
	MOV [BP-2], AX
	JMP L67		; line 14
L65:
L68:
	MOV AX, 600		; line 16
	PUSH AX
	POP AX
	MOV [BP-2], AX
L67:
L69:
	MOV AX, [BP-2]		; line 17
	CALL print_output
	CALL new_line
L70:
	MOV AX, 0		; line 19
	PUSH AX
	POP AX		; line 19
	JMP L1		; line 19
L1:
	MOV SP, BP
	POP BP
	MOV AX, 4CH
	INT 21H
main ENDP
new_line proc
	push ax
	push dx
	mov ah,2
	mov dl,0Dh
	int 21h
	mov ah,2
	mov dl,0Ah
	int 21h
	pop dx
	pop ax
	ret
new_line endp
print_output proc  ;print what is in ax
	push ax
	push bx
	push cx
	push dx
	push si
	lea si,number
	mov bx,10
	add si,4
	cmp ax,0
	jnge negate
print:
	xor dx,dx
	div bx
	mov [si],dl
	add [si],'0'
	dec si
	cmp ax,0
	jne print
	inc si
	lea dx,si
	mov ah,9
	int 21h
	pop si
	pop dx
	pop cx
	pop bx
	pop ax
	ret
negate:
	push ax
	mov ah,2
	mov dl,'-'
	int 21h
	pop ax
	neg ax
	jmp print
print_output endp
END main
