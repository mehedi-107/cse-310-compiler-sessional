#include "icg.hpp"



void handle_main_func_initialization(vector<string> &code) {
    code.push_back("main PROC");
    code.push_back("\tMOV AX, @DATA");
    code.push_back("\tMOV DS, AX");
}

void function_initialization(vector<string> &code){
    code.push_back("\tPUSH BP");
    code.push_back("\tMOV BP, SP");
}



void write_code_into_asm_file(const vector<string> &code, ofstream &asmFile) {
    for (const auto &line : code) {
        asmFile << line << endl;
    }
}

void handle_var_declaration(vector<string> &code, SymbolInfo *symbol, int& stack_offset,string name, string type, ofstream &asmFile) {
    if(symbol->getScopeId()==1) return;
    if(type=="int"){
    stack_offset += 2;
    symbol->setOffset(stack_offset);
    cout<<"Variable "<<symbol->getName()<<" declared with offset "<<stack_offset<<endl;
    code.push_back("\tSUB SP, 2");
    }
    else if(type=="int_array"){
        // extracting size from name
        string size_str;
        size_t pos = name.find('[');
        if (pos != string::npos) {
            size_str = name.substr(pos + 1);
            size_str = size_str.substr(0, size_str.size() - 1); // remove ']'
        } else {
            size_str = "1"; // default size if not specified
        }
        int size = stoi(size_str);
        stack_offset += 2 * size;
        symbol->setOffset(stack_offset);
        cout<<"Array "<<symbol->getName()<<" declared with offset "<<stack_offset<<endl;
        code.push_back("\tSUB SP, " + std::to_string(2 * size));
    }
}




void handle_assign_op(vector<string> &code, SymbolTable *symbolTable, const string &varName, int &stack_offset, ofstream &asmFile) {
    string var;
    // Check if the variable is an array
    if (varName.find('[') != string::npos) {
        var = varName.substr(0, varName.find('['));
    } else {
        var = varName;
    }
    SymbolInfo *symbol = symbolTable->look_up_in_all_scope(var);
    cout<<"Assigning "<<varName<<" with scope id "<<endl;
    if(symbol==nullptr) {cout<<"null"<<endl;return;}
    if(symbol->getScopeId()==1){
        string str = "\tPOP AX";
        code.push_back(str);
        if(var!=varName){
            str = "\tPOP BX";
            code.push_back(str);
            str = "\tPUSH AX";
            code.push_back(str);
            str = "\tMOV AX, 2";
            code.push_back(str);
            str = "\tMUL BX";
            code.push_back(str);
            str = "\tMOV BX, AX";
            code.push_back(str);
            str = "\tPOP AX";
            code.push_back(str);
            str = "\tMOV " + var +"[BX], AX";
        }
        else
            str = "\tMOV " + symbol->getName() + ", AX";
        code.push_back(str);
        stack_offset -= 2;
    }
    else {
        string str = "\tPOP AX";
        int offset = symbol->getOffset();
        code.push_back(str);
        if(var!=varName){
            str = "\tPOP BX";
            code.push_back(str);
            str = "\tPUSH AX";
            code.push_back(str);
            str = "\tMOV AX, 2";
            code.push_back(str);
            str = "\tMUL BX";
            code.push_back(str);
            str = "\tMOV BX, AX";
            code.push_back(str);
            str = "\tMOV AX, " + std::to_string(offset);
            code.push_back(str);
            str = "\tSUB AX, BX";
            code.push_back(str);
            str = "\tMOV BX, AX";
            code.push_back(str);
            str = "\tPOP AX";
            code.push_back(str);
            str = "\tMOV SI, BX";
            code.push_back(str);
            str = "\tNEG SI";
            code.push_back(str);
            str = "\tMOV [BP + SI], AX";
        }
        else
        str = "\tMOV [BP" + std::string(offset>=0 ? "-" : "+") + std::to_string(abs(offset)) + "], AX";
        code.push_back(str);

        stack_offset -= 2;
    }
    cout<<"done assigning "<<varName<<" with scope id "<<symbol->getScopeId()<<endl;
}