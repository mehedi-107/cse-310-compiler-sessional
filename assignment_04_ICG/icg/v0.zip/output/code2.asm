.MODEL SMALL
.STACK 1000H
.DATA
	number DB "00000$"
.CODE
main PROC
	MOV AX, @DATA
	MOV DS, AX
	PUSH BP
	MOV BP, SP
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
L1:
	MOV AX, 3		; line 5
	PUSH AX
	POP AX
	MOV [BP-2], AX
L2:
	MOV AX, 8		; line 6
	PUSH AX
	POP AX
	MOV [BP-4], AX
L3:
	MOV AX, 6		; line 7
	PUSH AX
	POP AX
	MOV [BP-6], AX
L4:
L5:
	MOV AX, 3		; line 10
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 10
	CMP AX, DX
	JE L6		; line 10
	JMP L7		; line 10
L6:
	MOV AX, 1		; line 10
	JMP L8		; line 10
L7:
	MOV AX, 0		; line 10
L8:
	PUSH AX		; line 10
	POP AX		; line 
	CMP AX, 0		; line 
	JE L10		; line 12
L9:
	MOV AX, [BP-4]		; line 11
	CALL print_output
	CALL new_line
L10:
L11:
	MOV AX, 8		; line 14
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-4]		; line 14
	CMP AX, DX
	JL L12		; line 14
	JMP L13		; line 14
L12:
	MOV AX, 1		; line 14
	JMP L14		; line 14
L13:
	MOV AX, 0		; line 14
L14:
	PUSH AX		; line 14
	POP AX		; line 14
	CMP AX, 0		; line 14
	JE L16		; line 14
L15:
	MOV AX, [BP-2]		; line 15
	CALL print_output
	CALL new_line
	JMP L17		; line 19
L16:
	MOV AX, [BP-6]		; line 18
	CALL print_output
	CALL new_line
L17:
L18:
	MOV AX, 6		; line 21
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-6]		; line 21
	CMP AX, DX
	JNE L19		; line 21
	JMP L20		; line 21
L19:
	MOV AX, 1		; line 21
	JMP L21		; line 21
L20:
	MOV AX, 0		; line 21
L21:
	PUSH AX		; line 21
	POP AX		; line 21
	CMP AX, 0		; line 21
	JE L23		; line 21
L22:
	MOV AX, [BP-6]		; line 22
	CALL print_output
	CALL new_line
	JMP L37		; line 33
L23:
L24:
	MOV AX, 8		; line 24
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-4]		; line 24
	CMP AX, DX
	JG L25		; line 24
	JMP L26		; line 24
L25:
	MOV AX, 1		; line 24
	JMP L27		; line 24
L26:
	MOV AX, 0		; line 24
L27:
	PUSH AX		; line 24
	POP AX		; line 24
	CMP AX, 0		; line 24
	JE L29		; line 24
L28:
	MOV AX, [BP-4]		; line 25
	CALL print_output
	CALL new_line
	JMP L37		; line 33
L29:
L30:
	MOV AX, 5		; line 27
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 27
	CMP AX, DX
	JL L31		; line 27
	JMP L32		; line 27
L31:
	MOV AX, 1		; line 27
	JMP L33		; line 27
L32:
	MOV AX, 0		; line 27
L33:
	PUSH AX		; line 27
	POP AX		; line 27
	CMP AX, 0		; line 27
	JE L35		; line 27
L34:
	MOV AX, [BP-2]		; line 28
	CALL print_output
	CALL new_line
	JMP L37		; line 33
L35:
	MOV AX, 0		; line 31
	PUSH AX
	POP AX
	MOV [BP-6], AX
L36:
	MOV AX, [BP-6]		; line 32
	CALL print_output
	CALL new_line
L37:
	MOV AX, 0		; line 36
	PUSH AX
	POP AX		; line 36
	JMP L38		; line 36
L38:
	MOV SP, BP
	POP BP
	MOV AX, 4CH
	INT 21H
main ENDP
new_line proc
	push ax
	push dx
	mov ah,2
	mov dl,0Dh
	int 21h
	mov ah,2
	mov dl,0Ah
	int 21h
	pop dx
	pop ax
	ret
new_line endp
print_output proc  ;print what is in ax
	push ax
	push bx
	push cx
	push dx
	push si
	lea si,number
	mov bx,10
	add si,4
	cmp ax,0
	jnge negate
print:
	xor dx,dx
	div bx
	mov [si],dl
	add [si],'0'
	dec si
	cmp ax,0
	jne print
	inc si
	lea dx,si
	mov ah,9
	int 21h
	pop si
	pop dx
	pop cx
	pop bx
	pop ax
	ret
negate:
	push ax
	mov ah,2
	mov dl,'-'
	int 21h
	pop ax
	neg ax
	jmp print
print_output endp
END main
