.MODEL SMALL
.STACK 1000H
.DATA
	number DB "00000$"
	i DW 1 DUP (0000H)
	j DW 1 DUP (0000H)
.CODE
main PROC
	MOV AX, @DATA
	MOV DS, AX
	PUSH BP
	MOV BP, SP
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
L1:
	MOV AX, 1		; line 6
	PUSH AX
	POP AX
	MOV i, AX
L2:
	MOV AX, i		; line7
	CALL print_output
	CALL new_line
L3:
	MOV AX, 5		; line 9
	PUSH AX
	MOV AX, 8		; line 9
	PUSH AX
	POP AX
	MOV DX, AX
	POP AX
	ADD AX, DX
	PUSH AX		; line 9
	POP AX
	MOV j, AX
L4:
	MOV AX, j		; line10
	CALL print_output
	CALL new_line
L5:
L6:
	MOV AX, 2		; line 12
	PUSH AX
L7:
	MOV AX, j		; line 12
	MOV CX, AX
	POP AX
	CWD
	MUL CX
	PUSH AX		; line 12
	POP AX
	MOV DX, AX
	MOV AX, i		; line 12
	ADD AX, DX
	PUSH AX		; line 12
	POP AX
	MOV [BP-2], AX
L8:
	MOV AX, [BP-2]		; line 13
	CALL print_output
	CALL new_line
L9:
L10:
	MOV AX, 9		; line 15
	PUSH AX
	POP AX
	MOV CX, AX
	MOV AX, [BP-2]		; line 15
	CWD
	DIV CX
	PUSH DX		; line 15
	POP AX
	MOV [BP-6], AX
L11:
	MOV AX, [BP-6]		; line 16
	CALL print_output
	CALL new_line
L12:
L13:
L14:
	MOV AX, [BP-4]		; line 18
	MOV DX, AX
	MOV AX, [BP-6]		; line 18
	CMP AX, DX
	JLE L15		; line 18
	JMP L16		; line 18
L15:
	MOV AX, 1		; line 18
	JMP L17		; line 18
L16:
	MOV AX, 0		; line 18
L17:
	PUSH AX		; line 18
	POP AX
	MOV [BP-8], AX
L18:
	MOV AX, [BP-8]		; line 19
	CALL print_output
	CALL new_line
L19:
L20:
L21:
	MOV AX, j		; line 21
	MOV DX, AX
	MOV AX, i		; line 21
	CMP AX, DX
	JNE L22		; line 21
	JMP L23		; line 21
L22:
	MOV AX, 1		; line 21
	JMP L24		; line 21
L23:
	MOV AX, 0		; line 21
L24:
	PUSH AX		; line 21
	POP AX
	MOV [BP-10], AX
L25:
	MOV AX, [BP-10]		; line 22
	CALL print_output
	CALL new_line
L26:
L27:
	MOV AX, [BP-8]
	CMP AX, 0
	JNE L29
L28:
	MOV AX, [BP-10]
	CMP AX, 0
	JE L30		; line 24
L29:
	MOV AX, 1
	JMP L31		; line 24
L30:
	MOV AX, 0		; line 24
L31:
	PUSH AX		; line 24
	POP AX
	MOV [BP-12], AX
L32:
	MOV AX, [BP-12]		; line 25
	CALL print_output
	CALL new_line
L33:
L34:
	MOV AX, [BP-8]
	CMP AX, 0
	JE L37
L35:
	MOV AX, [BP-10]
	CMP AX, 0
	JE L37		; line 27
L36:
	MOV AX, 1
	JMP L38		; line 27
L37:
	MOV AX, 0		; line 27
L38:
	PUSH AX		; line 27
	POP AX
	MOV [BP-12], AX
L39:
	MOV AX, [BP-12]		; line 28
	CALL print_output
	CALL new_line
L40:
	MOV AX, [BP-12]		; line 30
	PUSH AX		; line 30
	INC AX		; line 30
	MOV [BP-12], AX		; line 30
L41:
	MOV AX, [BP-12]		; line 31
	CALL print_output
	CALL new_line
L42:
L43:
	MOV AX, [BP-12]		; line 33
	NEG AX		; line 33
	PUSH AX		; line 33
	POP AX
	MOV [BP-2], AX
L44:
	MOV AX, [BP-2]		; line 34
	CALL print_output
	CALL new_line
L45:
	MOV AX, 0		; line 36
	PUSH AX
	POP AX		; line 36
	JMP L46		; line 36
L46:
	MOV SP, BP
	POP BP
	MOV AX, 4CH
	INT 21H
main ENDP
new_line proc
	push ax
	push dx
	mov ah,2
	mov dl,0Dh
	int 21h
	mov ah,2
	mov dl,0Ah
	int 21h
	pop dx
	pop ax
	ret
new_line endp
print_output proc  ;print what is in ax
	push ax
	push bx
	push cx
	push dx
	push si
	lea si,number
	mov bx,10
	add si,4
	cmp ax,0
	jnge negate
print:
	xor dx,dx
	div bx
	mov [si],dl
	add [si],'0'
	dec si
	cmp ax,0
	jne print
	inc si
	lea dx,si
	mov ah,9
	int 21h
	pop si
	pop dx
	pop cx
	pop bx
	pop ax
	ret
negate:
	push ax
	mov ah,2
	mov dl,'-'
	int 21h
	pop ax
	neg ax
	jmp print
print_output endp
END main
