.MODEL SMALL
.STACK 1000H
.DATA
	number DB "00000$"
.CODE
foo PROC		; line 1
	PUSH BP
	MOV BP, SP
L1:
L2:
L3:
	MOV AX, [BP+4]		; line 2
	MOV DX, AX
	MOV AX, [BP+6]		; line 2
	ADD AX, DX
	PUSH AX		; line 2
	MOV AX, 5		; line 2
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP+4]		; line 2
	CMP AX, DX
	JLE L4		; line 2
	JMP L5		; line 2
L4:
	MOV AX, 1		; line 2
	JMP L6		; line 2
L5:
	MOV AX, 0		; line 2
L6:
	PUSH AX		; line 2
	POP AX		; line 
	CMP AX, 0		; line 
	JE L8		; line 4
L7:
	MOV AX, 7		; line 3
	PUSH AX
	POP AX		; line 3
	JMP L8		; line 3
L8:
L9:
	MOV AX, 2		; line 5
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP+6]		; line 5
	SUB AX, DX
	PUSH AX		; line 5
L10:
	MOV AX, 1		; line 5
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP+4]		; line 5
	SUB AX, DX
	PUSH AX		; line 5
L11:
	MOV AX, [BP+6]		; line 5
	PUSH AX		; line 5
	POP AX
	PUSH AX		; line 5
	POP AX
	PUSH AX		; line 5
	MOV AX, [BP+4]		; line 5
	PUSH AX		; line 5
	POP AX
	PUSH AX		; line 5
	POP AX
	PUSH AX		; line 5
	CALL foo		; line 5
	PUSH AX		; line 5
	MOV AX, 2		; line 5
	PUSH AX
L12:
	MOV AX, 1		; line 5
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP+6]		; line 5
	SUB AX, DX
	PUSH AX		; line 5
L13:
	MOV AX, 2		; line 5
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP+4]		; line 5
	SUB AX, DX
	PUSH AX		; line 5
L14:
	MOV AX, [BP+6]		; line 5
	PUSH AX		; line 5
	POP AX
	PUSH AX		; line 5
	POP AX
	PUSH AX		; line 5
	MOV AX, [BP+4]		; line 5
	PUSH AX		; line 5
	POP AX
	PUSH AX		; line 5
	POP AX
	PUSH AX		; line 5
	CALL foo		; line 5
	PUSH AX		; line 5
	POP AX
	MOV CX, AX
	POP AX
	CWD
	MUL CX
	PUSH AX		; line 5
	POP AX
	MOV DX, AX
	POP AX
	ADD AX, DX
	PUSH AX		; line 5
	POP AX		; line 5
	JMP L15		; line 6
L15:
	MOV SP, BP
	POP BP
	RET 4
foo ENDP
main PROC
	MOV AX, @DATA
	MOV DS, AX
	PUSH BP
	MOV BP, SP
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
L16:
	MOV AX, 7		; line 11
	PUSH AX
	POP AX
	MOV [BP-2], AX
L17:
	MOV AX, 3		; line 12
	PUSH AX
	POP AX
	MOV [BP-4], AX
L18:
L19:
L20:
	MOV AX, [BP-2]		; line 14
	PUSH AX		; line 14
	MOV AX, [BP-4]		; line 14
	PUSH AX		; line 14
	CALL foo		; line 14
	PUSH AX		; line 14
	POP AX
	MOV [BP-6], AX
L21:
	MOV AX, [BP-6]		; line 15
	CALL print_output
	CALL new_line
L22:
	MOV AX, 0		; line 17
	PUSH AX
	POP AX		; line 17
	JMP L23		; line 17
L23:
	MOV SP, BP
	POP BP
	MOV AX, 4CH
	INT 21H
main ENDP
new_line proc
	push ax
	push dx
	mov ah,2
	mov dl,0Dh
	int 21h
	mov ah,2
	mov dl,0Ah
	int 21h
	pop dx
	pop ax
	ret
new_line endp
print_output proc  ;print what is in ax
	push ax
	push bx
	push cx
	push dx
	push si
	lea si,number
	mov bx,10
	add si,4
	cmp ax,0
	jnge negate
print:
	xor dx,dx
	div bx
	mov [si],dl
	add [si],'0'
	dec si
	cmp ax,0
	jne print
	inc si
	lea dx,si
	mov ah,9
	int 21h
	pop si
	pop dx
	pop cx
	pop bx
	pop ax
	ret
negate:
	push ax
	mov ah,2
	mov dl,'-'
	int 21h
	pop ax
	neg ax
	jmp print
print_output endp
END main
