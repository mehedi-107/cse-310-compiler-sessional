.MODEL SMALL
.STACK 1000H
.DATA
	number DB "00000$"
.CODE
main PROC
	MOV AX, @DATA
	MOV DS, AX
	PUSH BP
	MOV BP, SP
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
	SUB SP, 2
L1:
	MOV AX, 0		; line 5
	PUSH AX
	POP AX
	MOV [BP-2], AX
L2:
L3:
	MOV AX, 6		; line 5
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 5
	CMP AX, DX
	JL L4		; line 5
	JMP L5		; line 5
L4:
	MOV AX, 1		; line 5
	JMP L6		; line 5
L5:
	MOV AX, 0		; line 5
L6:
	PUSH AX		; line 5
	POP AX		; line 5
	CMP AX, 0		; line 5
	JE L10		; line 7
	JMP L8		; line 5
L7:
	MOV AX, [BP-2]		; line 5
	PUSH AX		; line 5
	INC AX		; line 5
	MOV [BP-2], AX		; line 5
	JMP L2		; line 5
L8:
	MOV AX, [BP-2]		; line 6
	CALL print_output
	CALL new_line
L9:
	JMP L7		; line 7
L10:
	MOV AX, 4		; line 9
	PUSH AX
	POP AX
	MOV [BP-6], AX
L11:
	MOV AX, 6		; line 10
	PUSH AX
	POP AX
	MOV [BP-8], AX
L12:
L13:
	MOV AX, 0		; line 11
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-6]		; line 11
	CMP AX, DX
	JG L14		; line 11
	JMP L15		; line 11
L14:
	MOV AX, 1		; line 11
	JMP L16		; line 11
L15:
	MOV AX, 0		; line 11
L16:
	PUSH AX		; line 11
	POP AX
	CMP AX, 0
	JE L20		; line 14
L17:
L18:
	MOV AX, 3		; line 12
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-8]		; line 12
	ADD AX, DX
	PUSH AX		; line 12
	POP AX
	MOV [BP-8], AX
L19:
	MOV AX, [BP-6]		; line 13
	PUSH AX		; line 13
	DEC AX		; line 13
	MOV [BP-6], AX		; line 13
	JMP L12		; line 14
L20:
	MOV AX, [BP-8]		; line 16
	CALL print_output
	CALL new_line
L21:
	MOV AX, [BP-6]		; line 17
	CALL print_output
	CALL new_line
L22:
	MOV AX, 4		; line 19
	PUSH AX
	POP AX
	MOV [BP-6], AX
L23:
	MOV AX, 6		; line 20
	PUSH AX
	POP AX
	MOV [BP-8], AX
L24:
L25:
	MOV AX, [BP-6]		; line 22
	PUSH AX		; line 22
	DEC AX		; line 22
	MOV [BP-6], AX		; line 22
	POP AX
	CMP AX, 0
	JE L28		; line 24
L26:
L27:
	MOV AX, 3		; line 23
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-8]		; line 23
	ADD AX, DX
	PUSH AX		; line 23
	POP AX
	MOV [BP-8], AX
	JMP L24		; line 24
L28:
	MOV AX, [BP-8]		; line 26
	CALL print_output
	CALL new_line
L29:
	MOV AX, [BP-6]		; line 27
	CALL print_output
	CALL new_line
L30:
	MOV AX, 0		; line 30
	PUSH AX
	POP AX		; line 30
	JMP L31		; line 30
L31:
	MOV SP, BP
	POP BP
	MOV AX, 4CH
	INT 21H
main ENDP
new_line proc
	push ax
	push dx
	mov ah,2
	mov dl,0Dh
	int 21h
	mov ah,2
	mov dl,0Ah
	int 21h
	pop dx
	pop ax
	ret
new_line endp
print_output proc  ;print what is in ax
	push ax
	push bx
	push cx
	push dx
	push si
	lea si,number
	mov bx,10
	add si,4
	cmp ax,0
	jnge negate
print:
	xor dx,dx
	div bx
	mov [si],dl
	add [si],'0'
	dec si
	cmp ax,0
	jne print
	inc si
	lea dx,si
	mov ah,9
	int 21h
	pop si
	pop dx
	pop cx
	pop bx
	pop ax
	ret
negate:
	push ax
	mov ah,2
	mov dl,'-'
	int 21h
	pop ax
	neg ax
	jmp print
print_output endp
END main
