.MODEL SMALL
.STACK 1000H
.DATA
	number DB "00000$"
	w DW 10 DUP (0000H)
.CODE
main PROC
	MOV AX, @DATA
	MOV DS, AX
	PUSH BP
	MOV BP, SP
	SUB SP, 2
	SUB SP, 20
L1:
	MOV AX, 0		; line 6
	PUSH AX
	MOV AX, 2		; line 6
	PUSH AX
	POP AX
	NEG AX		; line 6
	PUSH AX		; line 6
	POP AX
	POP BX
	PUSH AX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	POP AX
	MOV w[BX], AX
L2:
	MOV AX, 0		; line 7
	PUSH AX
	MOV AX, 0		; line 7
	PUSH AX
L3:
	POP BX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, w[BX]
	PUSH AX
	POP AX
	POP BX
	PUSH AX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, 22
	SUB AX, BX
	MOV BX, AX
	POP AX
	MOV SI, BX
	NEG SI
	MOV [BP + SI], AX
L4:
	MOV AX, 0		; line 8
	PUSH AX
L5:
	POP BX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, 22
	SUB AX, BX
	MOV BX, AX
	MOV SI, BX
	NEG SI
	MOV AX, [BP + SI]
	PUSH AX
	POP AX
	MOV [BP-2], AX
L6:
	MOV AX, [BP-2]		; line 9
	CALL print_output
	CALL new_line
L7:
	MOV AX, 1		; line 10
	PUSH AX
	MOV AX, 0		; line 10
	PUSH AX
L8:
	POP BX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, w[BX]
	PUSH AX
	INC AX
	MOV w[BX], AX
	POP AX
	POP BX
	PUSH AX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, 22
	SUB AX, BX
	MOV BX, AX
	POP AX
	MOV SI, BX
	NEG SI
	MOV [BP + SI], AX
L9:
	MOV AX, 1		; line 11
	PUSH AX
L10:
	POP BX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, 22
	SUB AX, BX
	MOV BX, AX
	MOV SI, BX
	NEG SI
	MOV AX, [BP + SI]
	PUSH AX
	POP AX
	MOV [BP-2], AX
L11:
	MOV AX, [BP-2]		; line 12
	CALL print_output
	CALL new_line
L12:
	MOV AX, 0		; line 13
	PUSH AX
L13:
	POP BX
	MOV AX, 2
	MUL BX
	MOV BX, AX
	MOV AX, w[BX]
	PUSH AX
	POP AX
	MOV [BP-2], AX
L14:
	MOV AX, [BP-2]		; line 14
	CALL print_output
	CALL new_line
L15:
L16:
	MOV AX, 0		; line 16
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 16
	ADD AX, DX
	PUSH AX		; line 16
	POP AX
	MOV [BP-2], AX
L17:
L18:
	MOV AX, 0		; line 17
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 17
	SUB AX, DX
	PUSH AX		; line 17
	POP AX
	MOV [BP-2], AX
L19:
L20:
	MOV AX, 1		; line 18
	PUSH AX
	POP AX
	MOV CX, AX
	MOV AX, [BP-2]		; line 18
	CWD
	MUL CX
	PUSH AX		; line 18
	POP AX
	MOV [BP-2], AX
L21:
	MOV AX, [BP-2]		; line 19
	CALL print_output
	CALL new_line
L22:
L23:
	MOV AX, 0		; line 21
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 21
	CMP AX, DX
	JG L24		; line 21
	JMP L25		; line 21
L24:
	MOV AX, 1		; line 21
	JMP L26		; line 21
L25:
	MOV AX, 0		; line 21
L26:
	PUSH AX		; line 21
L27:
	POP AX		; line 21
	CMP AX, 0
	JE L33
L28:
	MOV AX, 10		; line 21
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 21
	CMP AX, DX
	JL L29		; line 21
	JMP L30		; line 21
L29:
	MOV AX, 1		; line 21
	JMP L31		; line 21
L30:
	MOV AX, 0		; line 21
L31:
	PUSH AX		; line 21
	POP AX
	CMP AX, 0
	JE L33		; line 21
L32:
	MOV AX, 1
	JMP L34		; line 21
L33:
	MOV AX, 0		; line 21
L34:
	PUSH AX		; line 21
L35:
	POP AX		; line 21
	CMP AX, 0
	JNE L48
L36:
	MOV AX, 0		; line 21
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 21
	CMP AX, DX
	JL L37		; line 21
	JMP L38		; line 21
L37:
	MOV AX, 1		; line 21
	JMP L39		; line 21
L38:
	MOV AX, 0		; line 21
L39:
	PUSH AX		; line 21
L40:
	POP AX		; line 21
	CMP AX, 0
	JE L46
L41:
	MOV AX, 10		; line 21
	PUSH AX
	POP AX
	NEG AX		; line 21
	PUSH AX		; line 21
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 21
	CMP AX, DX
	JG L42		; line 21
	JMP L43		; line 21
L42:
	MOV AX, 1		; line 21
	JMP L44		; line 21
L43:
	MOV AX, 0		; line 21
L44:
	PUSH AX		; line 21
	POP AX
	CMP AX, 0
	JE L46		; line 21
L45:
	MOV AX, 1
	JMP L47		; line 21
L46:
	MOV AX, 0		; line 21
L47:
	PUSH AX		; line 21
	POP AX
	CMP AX, 0
	JE L49		; line 21
L48:
	MOV AX, 1
	JMP L50		; line 21
L49:
	MOV AX, 0		; line 21
L50:
	PUSH AX		; line 21
	POP AX		; line 21
	CMP AX, 0		; line 21
	JE L52		; line 21
L51:
	MOV AX, 100		; line 22
	PUSH AX
	POP AX
	MOV [BP-2], AX
	JMP L53		; line 22
L52:
	MOV AX, 200		; line 24
	PUSH AX
	POP AX
	MOV [BP-2], AX
L53:
	MOV AX, [BP-2]		; line 25
	CALL print_output
	CALL new_line
L54:
	MOV AX, 0		; line 27
	PUSH AX
	POP AX		; line 27
	JMP L55		; line 27
L55:
	MOV SP, BP
	POP BP
	MOV AX, 4CH
	INT 21H
main ENDP
new_line proc
	push ax
	push dx
	mov ah,2
	mov dl,0Dh
	int 21h
	mov ah,2
	mov dl,0Ah
	int 21h
	pop dx
	pop ax
	ret
new_line endp
print_output proc  ;print what is in ax
	push ax
	push bx
	push cx
	push dx
	push si
	lea si,number
	mov bx,10
	add si,4
	cmp ax,0
	jnge negate
print:
	xor dx,dx
	div bx
	mov [si],dl
	add [si],'0'
	dec si
	cmp ax,0
	jne print
	inc si
	lea dx,si
	mov ah,9
	int 21h
	pop si
	pop dx
	pop cx
	pop bx
	pop ax
	ret
negate:
	push ax
	mov ah,2
	mov dl,'-'
	int 21h
	pop ax
	neg ax
	jmp print
print_output endp
END main
