.MODEL SMALL
.STACK 1000H
.DATA
	number DB "00000$"
.CODE
main PROC
	MOV AX, @DATA
	MOV DS, AX
	PUSH BP
	MOV BP, SP
	SUB SP, 2
L1:
L2:
	MOV AX, 0		; line 3
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 3
	CMP AX, DX
	JG L3		; line 3
	JMP L4		; line 3
L3:
	MOV AX, 1		; line 3
	JMP L5		; line 3
L4:
	MOV AX, 0		; line 3
L5:
	PUSH AX		; line 3
L6:
	POP AX		; line 3
	CMP AX, 0
	JNE L11
L7:
	MOV AX, 10		; line 3
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 3
	CMP AX, DX
	JL L8		; line 3
	JMP L9		; line 3
L8:
	MOV AX, 1		; line 3
	JMP L10		; line 3
L9:
	MOV AX, 0		; line 3
L10:
	PUSH AX		; line 3
	POP AX
	CMP AX, 0
	JE L12		; line 3
L11:
	MOV AX, 1
	JMP L13		; line 3
L12:
	MOV AX, 0		; line 3
L13:
	PUSH AX		; line 3
	POP AX		; line 3
	CMP AX, 0		; line 3
	JE L15		; line 3
L14:
	MOV AX, 100		; line 4
	PUSH AX
	POP AX
	MOV [BP-2], AX
	JMP L16		; line 4
L15:
	MOV AX, 200		; line 6
	PUSH AX
	POP AX
	MOV [BP-2], AX
L16:
L17:
	MOV AX, 20		; line 8
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 8
	CMP AX, DX
	JG L18		; line 8
	JMP L19		; line 8
L18:
	MOV AX, 1		; line 8
	JMP L20		; line 8
L19:
	MOV AX, 0		; line 8
L20:
	PUSH AX		; line 8
L21:
	POP AX		; line 8
	CMP AX, 0
	JE L27
L22:
	MOV AX, 30		; line 8
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 8
	CMP AX, DX
	JL L23		; line 8
	JMP L24		; line 8
L23:
	MOV AX, 1		; line 8
	JMP L25		; line 8
L24:
	MOV AX, 0		; line 8
L25:
	PUSH AX		; line 8
	POP AX
	CMP AX, 0
	JE L27		; line 8
L26:
	MOV AX, 1
	JMP L28		; line 8
L27:
	MOV AX, 0		; line 8
L28:
	PUSH AX		; line 8
	POP AX		; line 8
	CMP AX, 0		; line 8
	JE L30		; line 8
L29:
	MOV AX, 300		; line 9
	PUSH AX
	POP AX
	MOV [BP-2], AX
	JMP L31		; line 9
L30:
	MOV AX, 400		; line 11
	PUSH AX
	POP AX
	MOV [BP-2], AX
L31:
L32:
	MOV AX, 40		; line 13
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 13
	CMP AX, DX
	JG L33		; line 13
	JMP L34		; line 13
L33:
	MOV AX, 1		; line 13
	JMP L35		; line 13
L34:
	MOV AX, 0		; line 13
L35:
	PUSH AX		; line 13
L36:
	POP AX		; line 13
	CMP AX, 0
	JE L42
L37:
	MOV AX, 50		; line 13
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 13
	CMP AX, DX
	JL L38		; line 13
	JMP L39		; line 13
L38:
	MOV AX, 1		; line 13
	JMP L40		; line 13
L39:
	MOV AX, 0		; line 13
L40:
	PUSH AX		; line 13
	POP AX
	CMP AX, 0
	JE L42		; line 13
L41:
	MOV AX, 1
	JMP L43		; line 13
L42:
	MOV AX, 0		; line 13
L43:
	PUSH AX		; line 13
L44:
	POP AX		; line 13
	CMP AX, 0
	JNE L57
L45:
	MOV AX, 60		; line 13
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 13
	CMP AX, DX
	JL L46		; line 13
	JMP L47		; line 13
L46:
	MOV AX, 1		; line 13
	JMP L48		; line 13
L47:
	MOV AX, 0		; line 13
L48:
	PUSH AX		; line 13
L49:
	POP AX		; line 13
	CMP AX, 0
	JE L55
L50:
	MOV AX, 70		; line 13
	PUSH AX
	POP AX
	MOV DX, AX
	MOV AX, [BP-2]		; line 13
	CMP AX, DX
	JG L51		; line 13
	JMP L52		; line 13
L51:
	MOV AX, 1		; line 13
	JMP L53		; line 13
L52:
	MOV AX, 0		; line 13
L53:
	PUSH AX		; line 13
	POP AX
	CMP AX, 0
	JE L55		; line 13
L54:
	MOV AX, 1
	JMP L56		; line 13
L55:
	MOV AX, 0		; line 13
L56:
	PUSH AX		; line 13
	POP AX
	CMP AX, 0
	JE L58		; line 13
L57:
	MOV AX, 1
	JMP L59		; line 13
L58:
	MOV AX, 0		; line 13
L59:
	PUSH AX		; line 13
	POP AX		; line 13
	CMP AX, 0		; line 13
	JE L61		; line 13
L60:
	MOV AX, 500		; line 14
	PUSH AX
	POP AX
	MOV [BP-2], AX
	JMP L62		; line 14
L61:
	MOV AX, 600		; line 16
	PUSH AX
	POP AX
	MOV [BP-2], AX
L62:
	MOV AX, [BP-2]		; line 17
	CALL print_output
	CALL new_line
L63:
	MOV AX, 0		; line 19
	PUSH AX
	POP AX		; line 19
	JMP L64		; line 19
L64:
	MOV SP, BP
	POP BP
	MOV AX, 4CH
	INT 21H
main ENDP
new_line proc
	push ax
	push dx
	mov ah,2
	mov dl,0Dh
	int 21h
	mov ah,2
	mov dl,0Ah
	int 21h
	pop dx
	pop ax
	ret
new_line endp
print_output proc  ;print what is in ax
	push ax
	push bx
	push cx
	push dx
	push si
	lea si,number
	mov bx,10
	add si,4
	cmp ax,0
	jnge negate
print:
	xor dx,dx
	div bx
	mov [si],dl
	add [si],'0'
	dec si
	cmp ax,0
	jne print
	inc si
	lea dx,si
	mov ah,9
	int 21h
	pop si
	pop dx
	pop cx
	pop bx
	pop ax
	ret
negate:
	push ax
	mov ah,2
	mov dl,'-'
	int 21h
	pop ax
	neg ax
	jmp print
print_output endp
END main
